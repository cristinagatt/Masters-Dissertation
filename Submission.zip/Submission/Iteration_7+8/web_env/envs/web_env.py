import gym
from gym import spaces
import numpy as np
import math
from random import randint
from datetime import datetime


from selenium import webdriver
from selenium.common.exceptions import *
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import logging

from web_driver_classes import Generic_site

class Web_Env(gym.Env):
    metadata={'render.modes': ['human']}

    def __init__(self,url):
        super (Web_Env,self).__init__()
        #type_of_action, element_no
        self.action_space=spaces.MultiDiscrete([3,42])

        #element (check_spreadsheet), cart_empty
        self.observation_space=spaces.Box(low=np.array([-1,0,0,0,0]), high=np.array([42,1,1,1,1]), shape=(5,), dtype=np.int32)


        self.done=False
        self.actions=[]
        self.observations=[]
        self.web_driver=None
        self.step_no=0
        self.goals=[]
        self.time=None
        self.url=url

        self.elements={0: "addtocart", 
        1: "login", 2: "username",
        3: "password", 4: "continue", 5:"account",
        6: "search", 7:"checkout", 8: "productlisting", 9: "menu", 
        10: "menuitem", 11:"submenuitem", 12: "removefromcart", 13: "basket",
        14: "cookies", 15: "allow", 16: "close", 17:"homepage", 18: "register", 19: "firstname", 
        20:"lastname", 21:"telephone",22: "passwordconfirm", 23: "agree", 24:"forgetpassword", 
        25: "editaccount", 26:"quantity", 27: "orderhistory", 28: "view", 29:"reasonforreturn", 30:"submit", 31:"currency", 32:"currencychange", 33:"addtowishlist", 34:"wishlist", 35:"contactus", 
        36:"enquiry", 37:"writeareview", 38:"review", 39:"rating", 40:"logout", 41:"return"}
        logging.basicConfig(level=logging.INFO, format='%(asctime)s.%(msecs)03d : %(message)s', handlers=[logging.StreamHandler(),logging.FileHandler('trial_monday.log')])
        logging.info("-----------MARCOPOLO - AN AUTOMATED TESTING AGENT----------")

        logging.info ("{:<15} {:<15} {:<15} {:<15} {:<15}".format("Step No", "Action", "Element", "Status", "Observation")) 
        logging.info ("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15} {:<15} {:<15}".format(" ", " ", " ", " ", "Items in cart?", "GDPR/cookies?", "Pop-ups?", "Signed-in?"))
    def reset(self):
        if(self.actions!=[]):
            self.log_file()
        self.actions=[]
        self.observations=[]
        self.time=datetime.now().timestamp()

        self.create_web_driver()
        #self.goal_id=[0,7]
        #self.goals=[0,7]
        self.experiment_name="Iteration_7_TesterData"
        self.step_no=0
   
        obs=np.array([-1,0,self.web_driver.cookies, self.web_driver.popup,0])
        self.observations.append(obs)
        self.percentage=0
        return obs

    
    def step(self,action):
        obs=self.take_action(action)

        self.actions.append(action)
        self.observations.append(obs)

        reward=0

        self.done=self.is_done()
        self.step_no+=1
        #self.percentage_done()

        return obs,reward,self.done,{}

    
    def render(self, mode='human', close=False):
        return
        #print(f"Step:{self.step_no}")
        #print(f"Actions:{self.actions}")
        #print(f"Observations:{self.observations}")

    def take_action(self,action):
    
        action_type=action[0]
        element_id=action[1]

        #CLICK
        if(action_type==0):
            obs= self.click_action(element_id,self.elements.get(element_id))
        elif(action_type==1):
            obs= self.keys_action(element_id,self.elements.get(element_id))
        elif(action_type==2):
            obs=self.home_page(element_id,self.elements.get(element_id))
        else:
            print("INVALID ACTION TYPE CHOSEN")

        #self.update_goal_id()

        if((self.observations[-1]==obs).all()):
            success="Invalid"
        else:
            success="Valid"
        self.logger(action,success,obs)
        return obs



    def logger(self,action,success,obs):
        action_type=action[0]
        element_id=action[1]

        if(action_type==0):
            act="Click"
        elif(action_type==1):
            act="Key"
        elif(action_type==2):
            act="Return home"
        logging.info ("{:<15} {:<15} {:<15} {:<15} {:<15} {:<15} {:<15} {:<15}".format(str(self.step_no), act, self.elements.get(element_id),success,str(obs[1]),str(obs[2]),str(obs[3]), str(obs[4])))


    def click_action(self,element_id,element_label):
        if(element_id in [0,1,4,5,7,8,9,10,11,12,13,15,16,18,23,24,25,27,28,29,30,31,32,33,34,35,36,37,39,40,41]):
            print("TO CLICK---->")
            self.web_driver.click(element_id,element_label)
        obs=np.array([self.web_driver.current_element,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup,self.web_driver.login])

        return obs

    def home_page(self,element_id,element_label):
        obs=None
        if(element_id in [17]):
            self.web_driver.go_to_home(element_id,element_label)
            obs=np.array([-1,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup,self.web_driver.login])
        else:   
            obs=np.array([self.web_driver.current_element,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup,self.web_driver.login])

        return obs

    def keys_action(self,element_id,element_label):
        obs=[]
        inp=""
        enter=False
        if(element_id in [2,3,6,19,20,21,22,26,36,38]):
            if(element_id==2):
                inp="msctestingagent@gmail.com"
            elif(element_id==3):
                if(self.url=="https://manomano.co.uk" or self.url=="http://localhost/opencart/"):
                    inp="TestingAgent21!"
                else:
                    inp="TestingAgent21"
            elif(element_id==6 and self.url!="https://newegg.com" and self.url!="https://manomano.co.uk" and self.url!="http://localhost/opencart/"):
                inp="Software Testing"
                enter=True
            elif(element_id==6 and (self.url=="https://newegg.com" or self.url=="https://manomano.co.uk")):
                inp="Star wars"
                enter=True
            elif(element_id==6 and self.url=="http://localhost/opencart/"):
                inp="ipad"
                enter=True
            elif(element_id==19):
                inp="Test Name"
            elif (element_id==20):
                inp="Test Surname"
            elif(element_id==21):
                inp="21345678"
            elif(element_id==22):
                inp="TestingAgent21!"
            elif(element_id==26):
                inp="2"
                enter=True
            elif(element_id==36 or element_id==37):
                inp="This is some text"
            self.web_driver.send_keys(element_id,inp,element_label,enter)


        obs=np.array([self.web_driver.current_element,self.web_driver.items_in_cart,self.web_driver.cookies, self.web_driver.popup,self.web_driver.login])
        return obs


    def create_web_driver(self):
        if(self.web_driver==None):
            self.web_driver=Generic_site.Drv(self.url)

        self.web_driver.reset()

    def close(self):
        self.web_driver.close()
    

    # def is_done(self):
    #     done=True
    #     for id in self.goal_id:
    #         if(id!=-2):
    #             done=False
    #             break
    #     return done

    # def is_done(self):
    #     done=True
    #     for id in self.goal_id:
    #         if(id!=[-2]):
    #             done=False
    #             break
    #     return done
        
    def is_done(self):
        done=True
        time_now=datetime.now().timestamp()
        if(time_now-self.time<3600):
            done=False

        return done
         

    # def percentage_done(self):
    #     no_of_goals=len(self.goal_id)
    #     no_of_goals_done= self.goal_id.count(-2)
    #     percentage= (no_of_goals_done/no_of_goals)*100 
    #     self.percentage=percentage
    #     print(percentage)

    # def percentage_done(self):
    #     no_of_goals=len(self.goal_id)
    #     no_of_goals_done= self.goal_id.count([-4])
    #     percentage= (no_of_goals_done/no_of_goals)*100 
    #     self.percentage=percentage
    #     print("Percentage completed: ", percentage)
    
    # def update_goal_id(self):
    #     if(self.web_driver.current_element==-1):
    #         return
    #     else: 
    #         if self.web_driver.current_element in self.goal_id:
    #             index=self.goal_id.index(self.web_driver.current_element)
    #             if(index==0):
    #                 self.goal_id[index]=-2
    #             elif(self.goal_id[index-1]==-2):
    #                 self.goal_id[index]=-2
    #         else:
    #             return


    # def is_sub_goal_achieved(self, goal_id):
    #     x=-2
    #     flag=True

    #     for i in range(len(goal_id)):
    #     # If current element is not
    #     # equal to X then break the
    #     # loop and print No
    #         if(goal_id[i] != x):
    #             flag = False
    #             break

    #     return flag

    # def update_goal_id(self):
    #     goal_ids=[]
    #     if(self.web_driver.current_element==-1):
    #         return
    #     else:
    #         ind=-1
    #         for goal_id in self.goal_id:
    #             ind+=1
    #             if self.web_driver.current_element in goal_id:
    #                 index=goal_id.index(self.web_driver.current_element)
    #                 if(index==0):
    #                     goal_id[index]=-2
    #                 elif goal_id[index-1]==-2:
    #                     goal_id[index]=-2

    #             goal_ids.append(goal_id)

    #             if(self.is_sub_goal_achieved(goal_id)):
    #                 goal_ids=self.goals
    #                 goal_ids[ind]=[-4]
    #                 self.goal_id=goal_ids
    #                 print("UPDATED GOALS: ", self.goal_id)
    #                 self.web_driver.current_element=-1
    #                 #self.web_driver.driver.get(self.url)
    #                 self.web_driver.get_relevant_elements()
    #                 return
            
    #     self.goal_id=goal_ids
    #     print("UPDATED GOALS: ", self.goal_id)


    
    def log_file(self):
        time= datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
        url= "URL:"+ self.url
        obs="Observations:"+ str(self.observations)
        act="Actions: "+ str(self.actions)
        steps="Steps: "+ str(self.step_no)

        content= time+ "\n"+ url+ "\n"+ obs + "\n" + act + "\n" + steps + "\n ---------------------------\n"

        f= open(self.experiment_name+".txt", 'a')
        f.write(content)
        f.close()




