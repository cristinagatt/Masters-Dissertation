import pickle
from imitation.data import types
import numpy as np

def main():
    acts_abe=[[0,1], [1,2], [1,3],[0,1]]
    obs_abe=[[-1,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)

    acts_alibris=[[0,1], [1,2], [1,3],[0,1]]
    obs_alibris=[[-1,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)

    acts_amazon=[[0,5],[1,2], [0,4], [1,3], [0,1]]
    obs_amazon=[[-1,0,0,0,0],[5,0,0,0,0], [2,0,0,0,0], [4,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)

    acts_manomano=[[0,15],[0,5],[1,2], [1,3], [0,1]]
    obs_manomano=[[-1,0,1,0,0],[-1,0,0,0,0],[5,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)

    acts_newegg=[[0,16],[0,1],[1,2],[0,1], [1,3], [0,1]]
    obs_newegg=[[-1,0,1,0,0],[-1,0,0,0,0],[1,0,0,0,0], [2,0,0,0,0],[1,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)

    acts_barnesandnoble=[[0,16],[0,5],[0,1],[1,2], [1,3], [0,1]]
    obs_barnesandnoble=[[-1,0,1,0,0],[-1,0,0,0,0],[5,0,0,0,0],[1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)

    # file=open('expert_alibris_login.pkl', 'wb')
    # pickle.dump(np.array([traj_alibris]), file, pickle.HIGHEST_PROTOCOL)


    # file=open('expert_amazon_login.pkl', 'wb')
    # pickle.dump(np.array([traj_amazon]), file, pickle.HIGHEST_PROTOCOL)

    # file=open('expert_abebooks_login.pkl', 'wb')
    # pickle.dump(np.array([traj_abe_books]), file, pickle.HIGHEST_PROTOCOL)

    file=open('expert_login_combined_event.pkl', 'wb')
    pickle.dump(np.array([traj_abe_books, traj_amazon, traj_manomano, traj_newegg, traj_barnesandnoble]), file, pickle.HIGHEST_PROTOCOL)

main()