import pickle
from imitation.data import types
import numpy as np


def go_to_account():

    actions = [[0,5]]
    obs = [[-1,0,0,0,0],[5,0,0,0,0]]

    traj_from_home =types.Trajectory(obs,actions, None)

    actions = [[0,5]]
    obs=[[-1,1,0,0,0], [5,1,0,0,0]]
    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,5]]
    obs=[[-1,1,0,0,1], [5,1,0,0,1]]
    traj_from_home_item_in_cart_logged=types.Trajectory(obs,actions,None)

    actions=[[0,5]]
    obs=[[-1,0,0,0,1], [5,0,0,0,1]]
    traj_from_home_logged=types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                     traj_from_home_item_in_cart,
                     traj_from_home_item_in_cart_logged,
                     traj_from_home_logged])

def login():

    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[-1,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0],[3,0,0,0,0], [1,0,0,0,1]]

    traj_from_home= types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[-1,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0],[3,1,0,0,0], [1,1,0,0,1]]

    traj_from_home_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3],[0,1]]
    obs=[[5,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0], [3,0,0,0,0], [1,0,0,0,1]]

    traj_from_account = types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3],[0,1]]
    obs=[[5,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1]]

    traj_from_account_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[1,2],[1,3],[0,1]]
    obs=[[7,1,0,0,0], [2,1,0,0,0], [3,1,0,0,0], [1,1,0,0,1]]

    traj_checkout=types.Trajectory(obs,actions,None)


    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[34,0,0,0,0], [1,0,0,0,0], [2,0,0,0,0],[3,0,0,0,0], [1,0,0,0,1]]

    traj_from_wl= types.Trajectory(obs,actions,None)

    actions=[[0,1],[1,2],[1,3], [0,1]]
    obs=[[34,1,0,0,0], [1,1,0,0,0], [2,1,0,0,0],[3,1,0,0,0], [1,1,0,0,1]]
    traj_from_wl_item= types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                     traj_from_home_item_in_cart,
                     traj_from_account_item_in_cart,
                     traj_from_account,
                     traj_checkout])


def search():
    actions= [[0,6]]
    obs=[[-1,0,0,0,0], [6,0,0,0,0]]

    traj_from_home=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,0], [6,1,0,0,0]]

    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,0,0,0,1],[6,0,0,0,1]]
    traj_from_home_search = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,1], [6,1,0,0,1]]
    traj_from_home_everything= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[0,1,0,0,0], [6,1,0,0,0]]

    traj_from_cart= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[0,1,0,0,1], [6,1,0,0,1]]
    traj_from_cart_login = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[13,1,0,0,0], [6,1,0,0,0]]

    traj_from_basket=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[13,1,0,0,1], [6,1,0,0,1]]
    traj_from_basket_login= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[12,0,0,0,0], [6,0,0,0,0]]
    traj_from_remove_from_cart=types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[12,0,0,0,1],[6,0,0,0,1]]
    traj_from_remove_from_cart_login= types.Trajectory(obs,actions,None)



    actions=[[1,6]]
    obs=[[5,0,0,0,1], [6,0,0,0,1]]
    traj_from_account_login = types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[5,1,0,0,1], [6,1,0,0,1]]
    traj_from_account_everything= types.Trajectory(obs,actions,None)


    actions=[[1,6]]
    obs=[[1,0,0,0,1], [6,0,0,0,1]]
    traj_from_login= types.Trajectory(obs,actions,None)

    actions=[[1,6]]
    obs=[[-1,1,0,0,1], [6,1,0,0,1]]
    traj_everything=types.Trajectory(obs,actions,None)

    return np.array([traj_from_home,
                    traj_from_home_item_in_cart,
                    traj_from_home_search,
                    traj_from_home_everything,
                    traj_from_cart,
                    traj_from_cart_login,
                    traj_from_basket,
                    traj_from_basket_login,
                    traj_from_remove_from_cart,
                    traj_from_remove_from_cart_login,
                    traj_from_account_login,
                    traj_from_account_everything,
                    traj_from_login,
                    traj_everything])

def add_to_cart():
    actions=[[0,0]]
    obs=[[8,0,0,0,0], [0,1,0,0,0]]
    traj_product_card=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,1,0,0,0], [0,1,0,0,0]]
    traj_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,0,0,0,1], [0,1,0,0,1]]
    traj_login=types.Trajectory(obs,actions,None)

    actions=[[0,0]]
    obs=[[8,1,0,0,1], [0,1,0,0,1]]
    traj_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_product_card, 
                     traj_item_in_cart, 
                     traj_everything, 
                     traj_login])

def select_item():
    actions=[[0,8]]
    obs=[[6,0,0,0,0], [8,0,0,0,0]]
    traj_search=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,1,0,0,0], [8,1,0,0,0]]
    traj_search_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,0,0,0,1], [8,0,0,0,1]]
    traj_search_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[6,1,0,0,1], [8,1,0,0,1]]
    traj_search_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,0,0,0,0], [8,0,0,0,0]]
    traj_from_home=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,1,0,0,0], [8,1,0,0,0]]
    traj_from_home_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,0,0,0,1], [8,0,0,0,1]]
    traj_from_home_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[-1,1,0,0,1], [8,1,0,0,1]]
    traj_from_home_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,0,0,0,0], [8,0,0,0,0]]
    traj_from_menu= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,1,0,0,0], [8,1,0,0,0]]
    traj_from_menu_item_in_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,0,0,0,1], [8,0,0,0,1]]
    traj_from_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[10,1,0,0,1], [8,1,0,0,1]]
    traj_from_menu_everything=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,0,0,0,0], [8,0,0,0,0]]
    traj_from_sub_menu=types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,1,0,0,0], [8,1,0,0,0]]
    traj_from_sub_menu_cart= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,0,0,0,1], [8,0,0,0,1]]
    traj_from_sub_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,8]]
    obs=[[11,1,0,0,1], [8,1,0,0,1]]
    traj_from_sub_menu_everything= types.Trajectory(obs,actions,None)
    

    return np.array([traj_search,
                    traj_search_item_in_cart,
                    traj_search_login,
                    traj_search_everything,
                    traj_from_home,
                    traj_from_home_login,
                    traj_from_home_everything,
                    traj_from_menu,
                    traj_from_menu_item_in_cart,
                    traj_from_menu_login,
                    traj_from_menu_everything,
                    traj_from_sub_menu,
                    traj_from_sub_menu_cart,
                    traj_from_sub_menu_everything,
                    traj_from_sub_menu_login]) 

def basket():
    actions=[[0,13]]
    obs=[[-1,1,0,0,0], [13,1,0,0,0]]
    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[-1,1,0,0,1], [13,1,0,0,1]]
    traj_from_home_everything=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[0,1,0,0,0], [13,1,0,0,0]]
    traj_from_item=types.Trajectory(obs,actions,None)

    actions=[[0,13]]
    obs=[[0,1,0,0,1], [13,1,0,0,1]]
    traj_from_item_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_from_home_item_in_cart, 
                     traj_from_home_everything, 
                     traj_from_item, 
                     traj_from_item_everything])

def checkout():
    actions=[[0,7]]
    obs=[[0,1,0,0,0], [7,1,0,0,0]]

    traj_checkout= types.Trajectory(obs,actions,None)

    actions= [[0,7]]
    obs= [[0,1,0,0,1], [7,1,0,0,1]]

    traj_checkout_login= types.Trajectory(obs,actions,None)

    actions=[[0,7]]
    obs=[[13,1,0,0,0], [7,1,0,0,0]]

    traj_basket= types.Trajectory(obs,actions,None)

    actions=[[0,7]]
    obs=[[13,1,0,0,1], [7,1,0,0,1]]

    traj_basket_login= types.Trajectory(obs,actions,None)

    return np.array([traj_checkout,
                     traj_checkout_login, 
                     traj_basket, 
                     traj_basket_login])

def remove_from_cart():
    actions=[[0,12]]
    obs=[[13,1,0,0,0],[12,0,0,0,0]]

    traj_basket=types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[0,1,0,0,0], [12,0,0,0,0]]

    traj_add_to_cart=types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[13,1,0,0,1], [12,0,0,0,1]]

    traj_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[0,1,0,0,1], [12,0,0,0,1]]

    traj_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_basket, 
                     traj_add_to_cart, 
                     traj_basket_login, 
                     traj_everything])


def go_home():
    actions=[[2,17]]
    obs=[[7,1,0,0,0], [-1,1,0,0,0]]

    traj_checkout= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[7,1,0,0,1], [-1,1,0,0,1]]

    traj_checkout_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[1,0,0,0,1], [-1,0,0,0,1]]

    traj_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[1,1,0,0,1], [-1,1,0,0,1]]

    traj_login_item= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[12,0,0,0,0],[-1,0,0,0,0]]

    traj_remove= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[12,0,0,0,1], [-1,0,0,0,1]]
    traj_remove_login= types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[13,1,0,0,0], [-1,1,0,0,0]]

    traj_basket=types.Trajectory(obs,actions,None)

    actions=[[2,17]]
    obs=[[13,1,0,0,1], [-1,1,0,0,1]]
    
    traj_basket_login= types.Trajectory(obs,actions,None)
    

    return np.array([traj_checkout, 
                     traj_checkout_login, 
                     traj_login, 
                     traj_login_item, 
                     traj_remove,
                     traj_remove_login,
                     traj_basket, 
                     traj_basket_login])

def cookies():
    actions=[[0,15]]
    obs=[[-1,0,1,0,0], [-1,0,0,0,0]]

    traj_close=types.Trajectory(obs,actions,None)


    actions=[[0,16]]
    obs=[[-1,0,1,0,0], [-1,0,0,0,0]]

    traj_accept = types.Trajectory(obs,actions,None)

    return np.array([traj_close, traj_accept])

def menu():

    actions=[[0,10]]
    obs=[[0,1,0,0,0], [10,1,0,0,0]]
    traj_menu_add_to_cart=types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[0,1,0,0,1], [10,1,0,0,1]]
    traj_menu_add_to_cart_login =types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[13,1,0,0,1], [10,1,0,0,1]]
    traj_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[13,1,0,0,0], [10,1,0,0,0]]
    traj_basket_item= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,0,0,0,0], [10,0,0,0,0]]
    traj_remove_from_cart=types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[12,0,0,0,1], [10,0,0,0,1]]
    traj_remove_from_cart_login= types.Trajectory(obs,actions,None)


    actions=[[0,9], [0,10]]
    obs=[[0,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0]]
    traj_header_menu_add_to_cart= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[0,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1]]
    traj_header_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,9],[0,10]]
    obs=[[13,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0]]
    traj_header_menu_basket=types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[13,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1]]
    traj_header_menu_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[12,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0]]
    traj_header_menu_remove= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10]]
    obs=[[12,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1]]
    traj_header_remove_login= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10],[0,11]]
    obs=[[0,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0],[11,1,0,0,0]]
    traj_sub_menu_add_to_cart= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10],[0,11]]
    obs=[[0,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1],[11,1,0,0,1]]
    traj_sub_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,9],[0,10],[0,11]]
    obs=[[13,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0],[11,1,0,0,0]]
    traj_sub_menu_basket=types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10],[0,11]]
    obs=[[13,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]
    traj_sub_menu_basket_login= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10],[0,11]]
    obs=[[12,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0],[11,0,0,0,0]]
    traj_sub_menu_remove= types.Trajectory(obs,actions,None)

    actions=[[0,9], [0,10],[0,11]]
    obs=[[12,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1],[11,0,0,0,1]]
    traj_sub_menu_remove_login= types.Trajectory(obs,actions,None)


    actions=[[0,10]]
    obs=[[-1,0,0,0,0],[10,0,0,0,0]]

    traj_menu= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,1,0,0,0], [10,1,0,0,0]]
    traj_menu_item= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,1,0,0,1], [10,1,0,0,1]]
    
    traj_menu_everything= types.Trajectory(obs,actions,None)

    actions=[[0,10]]
    obs=[[-1,0,0,0,1], [10,0,0,0,1]]

    traj_menu_login= types.Trajectory(obs,actions,None)

    actions=[[0,10], [0,11]]
    obs=[[-1,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]

    traj_submenu=types.Trajectory(obs,actions,None)

    actions=[[0,10], [0,11]]
    obs=[[-1,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]

    traj_submenu_item=types.Trajectory(obs,actions,None)


    actions=[[0,10], [0,11]]
    obs=[[-1,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]

    traj_submenu_login=types.Trajectory(obs,actions,None)


    actions=[[0,10], [0,11]]
    obs=[[-1,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]

    traj_submenu_everything=types.Trajectory(obs,actions,None)
    
    actions=[[0,9],[0,10],[0,11]]
    obs=[[-1,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0]]
    
    traj_menu_icon= types.Trajectory(obs,actions,None)


    actions=[[0,9],[0,10],[0,11]]
    obs=[[-1,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0]]
    
    traj_menu_icon_item= types.Trajectory(obs,actions,None)


    actions=[[0,9],[0,10],[0,11]]
    obs=[[-1,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1]]
    
    traj_menu_icon_login= types.Trajectory(obs,actions,None)


    actions=[[0,9],[0,10],[0,11]]
    obs=[[-1,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1]]
    
    traj_menu_icon_everything= types.Trajectory(obs,actions,None)


    actions=[[0,9],[0,10],[0,11],[0,11]]
    obs=[[-1,0,0,0,0], [9,0,0,0,0], [10,0,0,0,0], [11,0,0,0,0], [11,0,0,0,0]]

    traj_submenus= types.Trajectory(obs,actions,None)

    actions=[[0,9],[0,10],[0,11],[0,11]]
    obs=[[-1,1,0,0,0], [9,1,0,0,0], [10,1,0,0,0], [11,1,0,0,0], [11,1,0,0,0]]

    traj_submenus_item= types.Trajectory(obs,actions,None)


    actions=[[0,9],[0,10],[0,11],[0,11]]
    obs=[[-1,0,0,0,1], [9,0,0,0,1], [10,0,0,0,1], [11,0,0,0,1], [11,0,0,0,1]]

    traj_submenus_login= types.Trajectory(obs,actions,None)

    
    actions=[[0,9],[0,10],[0,11],[0,11]]
    obs=[[-1,1,0,0,1], [9,1,0,0,1], [10,1,0,0,1], [11,1,0,0,1], [11,1,0,0,1]]

    traj_submenus_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_menu,
            traj_menu_item,
            traj_menu_everything,
            traj_menu_login,
            traj_submenu,
            traj_submenu_item,
            traj_submenu_everything,
            traj_submenu_login,
            traj_menu_icon,
            traj_menu_icon_item,
            traj_menu_icon_login,
            traj_menu_icon_everything,
            traj_submenus,
            traj_submenus_item,
            traj_submenus_login,
            traj_submenu_everything,
            traj_menu_add_to_cart,
            traj_menu_add_to_cart_login,
            traj_basket_login,
            traj_basket_item,
            traj_remove_from_cart,
            traj_remove_from_cart_login,
            traj_header_menu_add_to_cart,
            traj_header_menu_login,
            traj_header_menu_basket,
            traj_header_menu_basket_login,
            traj_header_menu_remove,
            traj_header_remove_login,
            traj_sub_menu_add_to_cart,
            traj_sub_menu_login,
            traj_sub_menu_basket_login,
            traj_sub_menu_remove,
            traj_sub_menu_remove_login
            ])

def register():
    acts_register=[[0,5], [0,18], [1,19], [1,20], [1,2], [1,21], [1,3],[1,22],[0,23],[0,4],[2,17]]
    obs_register=[[-1,0,0,0,0], [5,0,0,0,0], [18,0,0,0,0], [19,0,0,0,0], [20,0,0,0,0],[2,0,0,0,0], [21,0,0,0,0], [3,0,0,0,0], [22,0,0,0,0],[23,0,0,0,0], [4,0,0,0,1],[-1,0,0,0,1]]

    traj_register=types.Trajectory(obs_register,acts_register,None)


    return np.array([traj_register])

def forgetpassword():
    acts_password=[[0,5], [0,1], [0,24],[1,2],[0,4],[2,17]]
    obs_password=[[-1,0,0,0,0], [5,0,0,0,0], [1,0,0,0,0], [24,0,0,0,0], [2,0,0,0,0], [4,0,0,0,0],[-1,0,0,0,0]]

    traj_password=types.Trajectory(obs_password, acts_password, None)

    return np.array([traj_password])



def edit_account():

    acts_account=[[0,5], [0,5], [0,25], [1,19], [1,20], [1,2], [1,21], [1,3],[1,22],[0,23],[0,4],[2,17]]
    obs_account=[[-1,0,0,0,1], [5,0,0,0,1],[5,0,0,0,1],[25,0,0,0,1], [19,0,0,0,1], [20,0,0,0,1],[2,0,0,0,1], [21,0,0,0,1], [3,0,0,0,1], [22,0,0,0,1],[23,0,0,0,1], [4,0,0,0,1],[-1,0,0,0,1]]

    traj_account=types.Trajectory(obs_account,acts_account, None)

    acts_account_1=[[0,5], [0,5], [0,25], [1,19], [1,20], [1,2], [1,21], [1,3],[1,22],[0,23],[0,4],[2,17]]
    obs_account_1=[[-1,1,0,0,1], [5,1,0,0,1],[5,1,0,0,1],[25,1,0,0,1], [19,1,0,0,1], [20,1,0,0,1],[2,1,0,0,1], [21,1,0,0,1], [3,1,0,0,1], [22,1,0,0,1],[23,1,0,0,1], [4,1,0,0,1],[-1,1,0,0,1]]

    traj_account_item_in_cart= types.Trajectory(obs_account_1,acts_account_1,None)

    return np.array([traj_account, traj_account_item_in_cart])

def update_quantity():
    acts_quantity= [[1,26], [0,7]]
    obs_quantity=[[13,1,0,0,0], [26,1,0,0,0],[7,1,0,0,0]]

    traj_quantity_out= types.Trajectory(obs_quantity,acts_quantity, None)

    acts_quantity_in= [[1,26], [0,7]]
    obs_quantity_in=[[13,1,0,0,1], [26,1,0,0,1],[7,1,0,0,1]]

    traj_quantity_in= types.Trajectory(obs_quantity_in,acts_quantity_in, None)

    acts_quantity_hm= [[1,26], [2,17]]
    obs_quantity_hm=[[13,1,0,0,0], [26,1,0,0,0],[-1,1,0,0,0]]
    traj_quantity_hm= types.Trajectory(obs_quantity_hm, acts_quantity_hm, None)
    
    acts_quantity_in_hm= [[1,26], [2,17]]
    obs_quantity_in_hm=[[13,1,0,0,1], [26,1,0,0,1],[-1,1,0,0,1]]

    traj_quantity_in_hm= types.Trajectory(obs_quantity_in_hm,acts_quantity_in_hm, None)

    return np.array([traj_quantity_hm,traj_quantity_in,traj_quantity_in_hm,traj_quantity_out])


def show_history():
    
    acts_history=[[0,5], [0,5], [0,27],[2,17]]
    obs_history=[[-1,0,0,0,1], [5,0,0,0,1],[5,0,0,0,1],[27,0,0,0,1],[-1,0,0,0,1]]

    traj_history=types.Trajectory(obs_history,acts_history, None)


    acts_history_1=[[0,5], [0,5], [0,27],[2,17]] 
    obs_history_1=[[-1,1,0,0,1], [5,1,0,0,1],[5,1,0,0,1],[27,1,0,0,1],[-1,1,0,0,1]]

    traj_history_item_in_cart= types.Trajectory(obs_history_1,acts_history_1,None)

    return np.array([traj_history, traj_history_item_in_cart])


def return_item():

    acts_return=[[0,5], [0,5], [0,27], [0,28], [0,41], [0,29],[0,30],[2,17]]
    obs_return=[[-1,0,0,0,1], [5,0,0,0,1],[5,0,0,0,1],[27,0,0,0,1], [28,0,0,0,1],[41,1,0,0,1],[29,0,0,0,1], [30,0,0,0,1],[-1,1,0,0,1]]

    traj_return=types.Trajectory(obs_return,acts_return, None)


    acts_return_1=[[0,5], [0,5], [0,27], [0,28],[0,41] ,[0,29], [0,30],[2,17]]
    obs_return_1=[[-1,1,0,0,1], [5,1,0,0,1],[5,1,0,0,1],[27,1,0,0,1],[28,1,0,0,1],[41,1,0,0,1] ,[29,1,0,0,1], [30,1,0,0,1], [-1,1,0,0,1]]

    traj_return_item_in_cart= types.Trajectory(obs_return_1,acts_return_1,None)

    return np.array([traj_return, traj_return_item_in_cart])


def change_currency():

    acts_currency=[[0,31], [0,32], [2,17]]
    obs_currency = [[-1,0,0,0,0], [31,0,0,0,0], [32,0,0,0,0], [-1,0,0,0,0]]

    traj_currency=types.Trajectory(obs_currency, acts_currency,None)


    acts_currency1=[[0,31], [0,32], [2,17]]
    obs_currency1 = [[-1,1,0,0,0], [31,1,0,0,0], [32,1,0,0,0], [-1,1,0,0,0]]

    traj_currency1=types.Trajectory(obs_currency1, acts_currency1,None)

    acts_currency2=[[0,31], [0,32], [2,17]]
    obs_currency2= [[-1,0,0,0,1], [31,0,0,0,1], [32,0,0,0,1], [-1,0,0,0,1]]

    traj_currency2=types.Trajectory(obs_currency2, acts_currency2,None)

    acts_currency3=[[0,31], [0,32], [2,17]]
    obs_currency3 = [[-1,1,0,0,1], [31,1,0,0,1], [32,1,0,0,1], [-1,1,0,0,1]]

    traj_currency3=types.Trajectory(obs_currency3, acts_currency3,None)

    return np.array([traj_currency,traj_currency1,traj_currency2,traj_currency3])


def add_to_wishlist():
    actions=[[0,33],[2,17]]
    obs=[[8,0,0,0,0], [33,1,0,0,0],[-1,1,0,0,0]]
    traj_product_card=types.Trajectory(obs,actions,None)

    actions=[[0,33],[2,17]]
    obs=[[8,1,0,0,0], [33,1,0,0,0],[-1,1,0,0,0]]
    traj_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,33],[2,17]]
    obs=[[8,0,0,0,1], [33,1,0,0,1],[-1,1,0,0,1]]
    traj_login=types.Trajectory(obs,actions,None)

    actions=[[0,33],[2,17]]
    obs=[[8,1,0,0,1], [33,1,0,0,1],[-1,1,0,0,1]]
    traj_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_product_card, 
                     traj_item_in_cart, 
                     traj_everything, 
                     traj_login])


def go_to_wishlist():
    actions=[[0,34]]
    obs=[[-1,1,0,0,0], [34,1,0,0,0]]
    traj_from_home_item_in_cart=types.Trajectory(obs,actions,None)

    actions=[[0,34]]
    obs=[[-1,1,0,0,1], [34,1,0,0,1]]
    traj_from_home_everything=types.Trajectory(obs,actions,None)

    actions=[[0,34]]
    obs=[[0,1,0,0,0], [34,1,0,0,0]]
    traj_from_item=types.Trajectory(obs,actions,None)

    actions=[[0,34]]
    obs=[[0,1,0,0,1], [34,1,0,0,1]]
    traj_from_item_everything= types.Trajectory(obs,actions,None)

    return np.array([traj_from_home_item_in_cart, 
                     traj_from_home_everything, 
                     traj_from_item, 
                     traj_from_item_everything])


def remove_from_wishlist():
    actions=[[0,12]]
    obs=[[34,1,0,0,1],[12,1,0,0,1]]

    traj_basket=types.Trajectory(obs,actions,None)

    actions=[[0,12]]
    obs=[[34,0,0,0,1], [12,0,0,0,1]]

    traj_add_to_cart=types.Trajectory(obs,actions,None)


    return np.array([traj_basket, 
                     traj_add_to_cart])


def contact_us():
    actions=[[0,35]]
    obs=[[-1,0,0,0,0], [35,0,0,0,0]]

    traj_1=types.Trajectory(obs,actions,None)

    actions=[[0,35]]
    obs=[[-1,1,0,0,0], [35,1,0,0,0]]
    traj_2=types.Trajectory(obs,actions,None)

    actions=[[0,35]]
    obs=[[-1,0,0,0,1], [35,0,0,0,1]]
    traj_3=types.Trajectory(obs,actions,None)

    actions=[[0,35]]
    obs=[[-1,1,0,0,1], [35,1,0,0,1]]

    traj_4=types.Trajectory(obs,actions,None)

    return np.array([traj_1,traj_2,traj_3,traj_4])

def contact_form():

    obs=[[35,0,0,0,0], [19,0,0,0,0],[2,0,0,0,0], [36,0,0,0,0],[30,0,0,0,0], [-1,0,0,0,0]]
    action=[[1,19], [1,2], [1,36], [0,30], [2,17]]

    traj_1=types.Trajectory(obs,action,None)

    obs=[[35,1,0,0,0], [19,1,0,0,0],[2,1,0,0,0], [36,1,0,0,0],[30,1,0,0,0], [-1,1,0,0,0]]
    action=[[1,19], [1,2], [1,36], [0,30], [2,17]]

    traj_2=types.Trajectory(obs,action,None)

    obs=[[35,0,0,0,1], [19,0,0,0,1],[2,0,0,0,1], [36,0,0,0,1],[30,0,0,0,1], [-1,0,0,0,1]]
    action=[[1,19], [1,2], [1,36], [0,30], [2,17]]

    traj_3=types.Trajectory(obs,action,None)

    obs=[[35,1,0,0,1], [19,1,0,0,1],[2,1,0,0,1], [36,1,0,0,1],[30,1,0,0,1], [-1,1,0,0,1]]
    action=[[1,19], [1,2], [1,36], [0,30], [2,17]]

    traj_4=types.Trajectory(obs,action,None)

    return np.array([traj_1,traj_2,traj_3,traj_4])


def logout():

    actions=[[0,5],[0,40],[2,17]]
    obs=[[-1,0,0,0,1], [5,0,0,0,1], [40,0,0,0,0],[-1,0,0,0,0]]

    traj_from_home= types.Trajectory(obs,actions,None)

    actions=[[0,5],[0,40],[2,17]]
    obs=[[-1,1,0,0,1], [5,1,0,0,1], [40,1,0,0,0],[-1,1,0,0,0]]

    traj_from_home_1= types.Trajectory(obs,actions,None)


    return np.array([traj_from_home,
                     traj_from_home_1]) 
    

def main():
    account=go_to_account()
    loggin=login()
    searched= search()
    menued=menu()
    added_to_cart=add_to_cart()
    baskets=basket()
    remove= remove_from_cart()
    item=select_item()
    home= go_home()
    cookie=cookies()
    checkedout=checkout()
    dregister=register()
    dforgetpassword= forgetpassword()
    dedit_account= edit_account()
    dupdate_quantity= update_quantity()
    dshow_history=show_history()
    dreturn_item=return_item()
    dchange_currency= change_currency()
    dadd_to_wishlist= add_to_wishlist()
    #dgo_to_wishlist=go_to_wishlist()
    #dremove_from_wishlist=remove_from_wishlist()
    dcontact_us=contact_us()
    dcontact_form= contact_form()
    dlogout=logout()


    arr=np.concatenate([dlogout,account,loggin,searched,menued,added_to_cart,baskets,remove,item,home,cookie,checkedout, dregister, dforgetpassword, dedit_account, dupdate_quantity, dshow_history,dreturn_item, dchange_currency, dadd_to_wishlist, dcontact_us,dcontact_form])

    #arr=np.concatenate([account,loggin,searched,menued,added_to_cart,baskets,remove,item,home,cookie,checkedout, dregister, dforgetpassword, dedit_account,dupdate_quantity,dshow_history])

    file=open('component_expert_testers.pkl', 'wb')
    pickle.dump(arr, file, pickle.HIGHEST_PROTOCOL)

main()


