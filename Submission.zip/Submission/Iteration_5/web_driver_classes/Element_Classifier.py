import math
import re
from collections import Counter
from selenium import webdriver
from time import sleep

import re
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains



class Classifier():
    def __init__(self,url):
        self.relevant_elements=[]
        self.WORD = re.compile(r"\w+")
        #self.elements=elements
        self.url=url
    
    def get_cosine(self,vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])

        sum1 = sum([vec1[x] ** 2 for x in list(vec1.keys())])
        sum2 = sum([vec2[x] ** 2 for x in list(vec2.keys())])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
            return 0.0
        else:
            return float(numerator) / denominator

    
    def text_to_vector(self,text):
        words=self.WORD.findall(text)
        return Counter(words)
        
    
    def create_labels(self):
        add_to_cart=['addtocart', 'addtobasket', 'addtoshoppingcart', 'addtobasketlink' ]
        cart=['basket', 'cart', 'shoppingcart', 'cartcontains', 'bag', 'itemsincart', 'viewcart', 'viewbasket', 'viewshoppingcart', 'no,continuetocart', 'viewcart&checkout']
        login=['login', 'signin', 'login', 'signon', 'account', 'signinsubmit', 'signin/register', 'securesignin']
        checkout = ['checkout', 'proceedtocheckout', 'placeorder', 'proceedtocheckout(1item)', 'gotodelivery', 'securecheckout','placeorderbutton']
        username= ['username', 'email']
        password=['password']
        search = ['search', 'searchquery', 'searchforanything', 'searchbox','searchsite']
        product_card=['productlisting','product','booktitle', 'item','listing', 'cardlink','itemtitle', 'itemimg','viewdetails']
        quantity_field=['quantity', 'qty']
        remove_item=['removefromcart','remove', 'removeitem', 'removebasket', 'removebasket1', 'delete', 'deleteitem' ]
        menu_item=['menuitem', 'hmenuitem']
        menu= ['menu','category', 'shop', 'openmenu',  'productmenu' ]
        continues=['continue']
        account=['account', 'account&lists', 'youraccount', 'myaccount']
        submenu=['submenuitem']
        cookies=['cookies', 'gdpr', 'cookiesbarlink']
        allow=['allow', 'allowandclose', 'acceptallcookies']
        popup=['popup']
        close=['close', 'no,thanks']
        
        label_categories=[add_to_cart, cookies, allow, close,popup, cart, login, checkout, username,submenu, password, search, product_card, quantity_field,remove_item, menu_item, menu, continues,account]
        return label_categories

    
    def load_element_attributes(self, element):
        attributes=['id', 'label', 'href', 'class', 'title', 'aria-label', 'name', 'type', 'alt', 'value']
        attributes=['id', 'label', 'href', 'class', 'aria-label','name', 'value','title']
        
        element_attributes=[]
        elem_text=None
        x=0
        for attribute in attributes:
            elem_attrib=None

            
            try:
                elem_attrib=element.get_attribute(attribute)
              
            except Exception as e:
                x=0
            
            if elem_attrib !=None:
                elem_attrib=elem_attrib.replace('-', '')
                elem_attrib= elem_attrib.replace('_', '')
                elem_attrib= elem_attrib.replace(' ', '')
                elem_attrib=elem_attrib.lower()
                element_attributes.append(elem_attrib)
                
        try: 
            elem_text=element.text
            elem_text=elem_text.replace('-', '')
            elem_text= elem_text.replace('_', '')
            elem_text= elem_text.replace(' ', '')
            elem_text=elem_text.lower()
        except Exception as e:
            x=0
            
        if(elem_text!=None):
            element_attributes.append(elem_text)

        return element_attributes
        
    def label_element(self,element_attributes, label_categories):
        classified_label=None
        cosine=0
        record=0
        
        for attribute in element_attributes:
    
            for category in label_categories:
                for label in category:
                    
                    vector1=self.text_to_vector(attribute)
                    vector2=self.text_to_vector(label)
                    
                    cosine=self.get_cosine(vector2, vector1)
                    
                    if(cosine>=0.75 and cosine>record):
                        record=cosine
                        classified_label=category[0]

                    if(cosine>=1):
                        classified_label=category[0]
                        return classified_label,cosine
        return classified_label,cosine


    def hard_coded_labels(self,element):
        label=None
        cosine=0
        try:
            if(self.url=="https://amazon.com"):
                if(element.get_attribute("class")=="a-link-normal a-text-normal"):
                    label='productlisting'
                    cosine=1.7
                elif(element.get_attribute("class")=="product-image"):
                    label='productlisting'
                    cosine=1.9
                elif(element.get_attribute("class")=="hmenu-item" and element.get_attribute("data-menu-id")=="5"):
                    label='menuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="hmenu-item" and element.get_attribute("data-menu-id")==None):
                    label="submenuitem"
                    cosine=1.2
                elif(element.get_attribute("class")=="a-size-small sc-action-delete"):
                    label="removefromcart"
                    cosine=1.2 
                elif(element.get_attribute("class")=="a-link-normal s-faceout-link a-text-normal"):
                    label='productlisting'
                    cosine=1.3  
                elif(element.get_attribute("class")=="a-link-normal s-no-outline"):
                    label='productlisting'
                    cosine=1.4  
                elif(element.get_attribute("class")=="a-link-normal a-color-base a-text-normal"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("id")=="nav-link-accountList"):
                    label='account'
                    cosine=1.2
                elif(element.get_attribute("class")=="a-touch-link a-box a-touch-link-noborder"):
                    label="submenuitem"
                    cosine=1.2
               # elif(element.get_attribute("class")=="a-truncate-cut"):
                #    label="productlisting"
                 #   cosine=1.5
                #elif(element.get_attribute("class")=="a-image-container a-dynamic-image-container _quad-card_style_quadrant__1Y3Y7"):
                #    label="productlisting"
                #    cosine=1.0

            elif(self.url=="https://abebooks.com"):
                if(element.get_attribute("class")=='product-title-link line-clamp-2 truncate-title'):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")=="srp-item-detail-link"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("id")=="hdr-nbc"):
                    label="menuitem"
                    cosine=1.2
                elif(element.get_attribute("id")=="header-searchbox-input-m"):
                    label="search"
                    cosine=1.2
                elif(element.get_attribute("id")=="header-searchbox-input"):
                    label="search"
                    cosine=1.2

            elif(self.url=="https://alibris.com"):
                
                if(element.get_attribute("class")=="mw-link-style"):
                    label="productlisting"
                    cosine=1.2
                elif(element.get_attribute("class")=="image"):
                    label="productlisting"
                    cosine=1.2
                elif("/search/books/isbn/" in element.get_attribute("href")):
                    label="productlisting"
                    cosine=1.2
                elif(element.get_attribute("class")=="image mw-yml-cell"):
                    label="productlisting"
                    cosine=1.2
                elif(element.get_attribute("class")=="btn oneClick mw-button-orange-4 mw-button-for-login"):
                    label="login"
                    cosine=1.2
                elif(element.get_attribute("class")=="dropdown-toggle sign-in mw-links"):
                    label="login"
                    cosine=1.2
                elif(element.get_attribute("class")=="dropdown-toggle nav-top"):
                    label="menuitem"
                    coine=1.2
                elif(element.get_attribute("class")=="dropdown-toggle nav-top mw-nav-link"):
                    label="menuitem"
                    coine=1.2
                elif(element.get_attribute("class")=="mw-header-btn mw-header-nav-btn mw-icon-list"):
                    label='menu'
                    cosine=1.2
                elif(element.text=="Accounting"): #Business Management
                    label='submenuitem'
                    cosine=1.2
                elif("/cart.delete?invId=" in element.get_attribute("href")):
                    label="removefromcart"
                    cosine=1.2
                elif(element.get_attribute("class")=="mw-nav-sublink mw-nav-homelink"):
                    label="submenuitem"
                    cosine=1.2


            elif(self.url=="https://manomano.co.uk"):
                if("ManoMano uses cookies" in element.text):
                    label='cookies'
                    cosine=1.2
                elif("container_carouselCard" in element.get_attribute("class") or "root_52804de5" in element.get_attribute("class") or "root_f8d42b04" in element.get_attribute("class")  or "root_2e4bce6d" in element.get_attribute("class") or "root_a64399e6" in element.get_attribute("class")):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")=="category-list__link" or element.get_attribute("class")=="category-preview__list-link"):
                    label='submenuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="styles_buttonTransparent__16gNl styles_button__1qpWo styles_familyTab__3sbwO"):
                    label='menuitem'
                    cosine=1.2
                elif(element.get_attribute("class")== "styles_buttonTransparent__16gNl styles_button__1qpWo styles_productTab__TaZ1_"):
                    label='menu'
                    cosine=1.2
                elif(element.text=="Garden and outdoor"):
                    label= 'menuitem'
                    cosine=1.0
                elif(element.text=="See all « Garden and outdoor »"):
                    label= 'submenuitem'
                    cosine=1.0
                elif(element.text=="View basket"):
                    label="basket"
                    cosine=10
                elif(element.get_attribute("href")=="/hub/garden-and-outdoor-823"):
                    label="menuitem"
                    cosine=1.0
                
            elif(self.url=="https://newegg.com"):
                if(element.get_attribute("id")== "onetrust-policy-text"):
                    label="cookies"
                    cosine=1.2
                elif(element.text=="Cookie Policy"):
                    label="mismatch"
                    cosine=0
                elif(element.get_attribute("class")=="item-mg margin-bottom" or element.get_attribute("class")=="link-more"):
                    label="popup"
                    cosine=1.2
                elif(element.get_attribute("class")=="button button color-blue btn-delete-item"):
                    label="removefromcart"
                    cosine=1.2
                elif(element.get_attribute("class")=="goods-title font-1"):
                    label="popup"
                    cosine=1.2
                elif(element.get_attribute("class")=="link icon-only header-menu-icon panel-open"):
                    label='menu'
                    cosine=1.2
                elif(element.get_attribute("class")=="item-content item-link"):
                    label="menuitem"
                    cosine=1.2
                elif(element.get_attribute("class")=="menu-list-link bg-transparent-lightblue"):
                    label="menuitem"
                    cosine=1.2

                elif(element.get_attribute("class")=="filter-box-label main-nav-third-title"):
                    label='submenuitem'
                    cosine=1.2
                    

                elif(element.get_attribute("class")=="item-content external"):
                    label='submenuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="nav-list-link"):
                    label='menuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="filter-box-label main-nav-third-title"):
                    label='submenuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="External"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")=="item-container external flex-wrap align-items-flex-start"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")== "external home-col-item home-pdt-item"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("placeholder")=="Keywords, Model #, Item #"):
                    label="search"
                    cosine=1.2
                elif(element.get_attribute("type")=="search"):
                    label="search"
                    cosine=1.3
                elif(element.get_attribute("class")=="link icon-only external header-cart-icon"):
                    label="basket"
                    cosine=1.2
                elif(element.get_attribute("class")=="icon material-icons icon-Close"):
                    label="close"
                    cosine=1.0
                    
            elif(self.url=="https://www.barnesandnoble.com"):
                if(element.get_attribute("id")== "onetrust-policy-text"):
                    label="cookies"
                    cosine=1.2
                elif(element.text=="Cookie Policy"):
                    label="mismatch"
                    cosine=0
                elif(element.get_attribute("id")== "rhfCategoryFlyout_account"):
                    label='account'
                    cosine=1.0
                elif(element.get_attribute("id")=="emailSignup"):
                    label="mismatch"
                    cosine=0
                elif(element.get_attribute("class")==" "):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")=="rbt-input-main form-control rbt-input"):
                    label='search'
                    cosine=1.2
                elif(element.get_attribute("class")=="rbt-input-main form-control rbt-input user-success"):
                    label='search'
                    cosine=1.2
                elif(element.get_attribute("class")=="image-container"):
                    label='productlisting'
                    cosine=1.2
                elif(element.get_attribute("class")=="navbar-toggler nonResponsive-mobile"):
                    label='menu'
                    cosine=1.2
                elif("rhfCategoryFlyout" in element.get_attribute("id")):
                    label='menuitem'
                    cosine=1.2
                elif(element.get_attribute("class")=="btn btn--large" and element.text=="Sign In & Continue"):
                    label='login'
                    cosine=1.2
            else:
                label=None
                cosine=0
        except:
            return None,0
        
        return label,cosine

    def classify(self,elements):
        label_categories=self.create_labels()
        for element in elements:
            attributes=self.load_element_attributes(element)


            label,cosine= self.hard_coded_labels(element)
            

            if(label==None):
                label,cosine=self.label_element(attributes,label_categories)
                

            if(label!=None):
                if(element.is_displayed()):
                    elem= {'label': label, "element": element, "cosine": cosine, 'iframe': None}
                    self.relevant_elements.append(elem)
        return self.relevant_elements

    def classify_frame(self,elements,driver):
        label_categories=self.create_labels()
        for element in elements:
            driver.switch_to_frame(element['iframe'])
            attributes=self.load_element_attributes(element['element'])

            label,cosine= self.hard_coded_labels(element['element'])

            if(label==None):
                label,cosine=self.label_element(attributes,label_categories)
                
            if(label!=None):
                if(element['element'].is_displayed()):
                    elem= {'label': label, "element": element['element'], "cosine": cosine, 'iframe': element['iframe']}
                    self.relevant_elements.append(elem)
                    print("CLASSIFY FRAME", elem)
            driver.switch_to_default_content()
        return self.relevant_elements

    

