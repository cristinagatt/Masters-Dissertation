#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  9 08:42:45 2021

@author: master
"""

from stable_baselines3.common.env_checker import check_env
from web_env.envs.web_env import Web_Env 

env = Web_Env()
# It will check your custom environment and output additional warnings if needed
check_env(env)
