import math
import re
from collections import Counter
from selenium import webdriver
from time import sleep

import re
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains



class Classifier():
    def __init__(self, elements,url):
        self.relevant_elements=[]
        self.WORD = re.compile(r"\w+")
        self.elements=elements
        self.url=url
    
    def get_cosine(self,vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])

        sum1 = sum([vec1[x] ** 2 for x in list(vec1.keys())])
        sum2 = sum([vec2[x] ** 2 for x in list(vec2.keys())])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)

        if not denominator:
            return 0.0
        else:
            return float(numerator) / denominator

    
    def text_to_vector(self,text):
        words=self.WORD.findall(text)
        return Counter(words)
        
    
    def create_labels(self):
        add_to_cart=['addtocart', 'addtobasket', 'addtoshoppingcart', 'addtobasketlink' ]
        cart=['basket', 'cart', 'shoppingcart', 'cartcontains', 'bag', 'itemsincart', 'viewcart']
        login=['login', 'signin', 'login', 'signon', 'account', 'signinsubmit']
        remove_from_cart=['remove', 'delete', 'removeitem', 'deleteitem']
        checkout = ['checkout', 'proceedtocheckout', 'placeorder', 'proceedtocheckout(1item)']
        username= ['username', 'email']
        password=['password']
        search = ['search', 'searchquery', 'searchforanything', 'searchbox']
        product_card=['productlisting','product', 'item','listing', 'cardlink']
        quantity_field=['quantity', 'qty']
        remove_item=['removefromcart','remove', 'removeitem', 'removebasket', 'removebasket1' ]
        menu_item=['menuitem', 'hmenuitem']
        menu= ['menu','category', 'shop', 'openmenu' ]
        continues=['continue']
        account=['account', 'account&lists', 'youraccount']
        submenu=['submenuitem']
        
        label_categories=[add_to_cart, cart, login, remove_from_cart, checkout, username,submenu, password, search, product_card, quantity_field,remove_item, menu_item, menu, continues,account]
        return label_categories

    
    def load_element_attributes(self, element):
        attributes=['id', 'label', 'href', 'class', 'title', 'aria-label', 'name', 'type', 'alt', 'value']
        
        element_attributes=[]
        elem_text=None
        x=0
        for attribute in attributes:
            elem_attrib=None

            
            try:
                elem_attrib=element.get_attribute(attribute)
              
            except Exception as e:
                x=0
            
            if elem_attrib !=None:
                elem_attrib=elem_attrib.replace('-', '')
                elem_attrib= elem_attrib.replace('_', '')
                elem_attrib= elem_attrib.replace(' ', '')
                elem_attrib=elem_attrib.lower()
                element_attributes.append(elem_attrib)
                
        try: 
            elem_text=element.text
            elem_text=elem_text.replace('-', '')
            elem_text= elem_text.replace('_', '')
            elem_text= elem_text.replace(' ', '')
            elem_text=elem_text.lower()
        except Exception as e:
            x=0
            
        if(elem_text!=None):
            element_attributes.append(elem_text)

        return element_attributes
        
    def label_element(self,element_attributes, label_categories):
        classified_label=None
        cosine=0
        record=0
        
        for attribute in element_attributes:
    
            for category in label_categories:
                for label in category:
                    
                    vector1=self.text_to_vector(attribute)
                    vector2=self.text_to_vector(label)
                    
                    cosine=self.get_cosine(vector2, vector1)
                    
                    if(cosine>=0.75 and cosine>record):
                        record=cosine
                        classified_label=category[0]

                    if(cosine>=1):
                        classified_label=category[0]
                        return classified_label,cosine
        return classified_label,cosine

    def hard_coded_labels(self,element):
        try:
            if(self.url=="https://amazon.com" and (element.get_attribute("class")=="a-link-normal a-text-normal" or element.get_attribute("class")=="a-list-item")):
                label='productlisting'
                cosine=1.5
                return label,cosine

            elif(self.url=="https://abebooks.com" and element.get_attribute("class")=="product-title-link line-clamp line-clamp-2 truncate-title"):
                label="productlisting"
                cosine=1.5
                return label,cosine
            elif(self.url=="https://amazon.com" and element.get_attribute("class")=="hmenu-item" and element.get_attribute("data-menu-id")=="5"):
                label='menuitem'
                cosine=2.0
                return label,cosine
            elif(self.url=="https://amazon.com" and element.get_attribute("class")=="hmenu-item" and element.get_attribute("data-menu-id")==None ):
                label="submenuitem"
                cosine=1.0
                return label, cosine
            elif (self.url=="https://abebooks.com" and element.get_attribute("id")=="hdr-nbc"):
                label="menuitem"
                cosine=2.0
                return label,cosine
            elif(self.url=="https://amazon.com" and element.get_attribute("class")=="a-size-small sc-action-delete"):
                label="removefromcart"
                cosine=1.2
                return label,cosine
            elif(self.url=="https://alibris.com" and element.get_attribute("class")=="image"):
                label="productlisting"
                cosine=1.2
                return label,cosine
            elif(self.url=="https://alibris.com" and element.get_attribute("class")=="dropdown-toggle nav-top"):
                label="menuitem"
                cosine=1.2
                return label,cosine
            elif(self.url=="https://alibris.com" and element.text=="Business Management"):
                label="submenuitem"
                cosine=1.2
                return label,cosine
            elif(self.url=="https://alibris.com" and ("/cart.delete?invId=") in element.get_attribute("href")):
                label="removefromcart"
                cosine=1.2
                return label,cosine
            elif(self.url=="https://amazon.com" and element.get_attribute("id")=="nav-link-accountList"):
                label="account"
                cosine=1.2
                return label,cosine
 
            
            else:
                return None,0
        except:
            return None,0

    def classify(self):
        label_categories=self.create_labels()
        for element in self.elements:
            attributes=self.load_element_attributes(element)

            label,cosine= self.hard_coded_labels(element)
            

            if(label==None):
                label,cosine=self.label_element(attributes,label_categories)
                

            if(label!=None):
                if(element.is_displayed()):
                    elem= {'label': label, "element": element, "cosine": cosine}
                    self.relevant_elements.append(elem)
        return self.relevant_elements
    

