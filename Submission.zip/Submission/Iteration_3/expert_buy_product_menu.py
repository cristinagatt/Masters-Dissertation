import pickle
from imitation.data import types
import numpy as np

def main():
    acts_abe=[[0,10], [0,8],[0,0],[0,7]]
    obs_abe=[[-1,0,0,0], [10,0,0,0], [8,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_abe_books=types.Trajectory(obs_abe,acts_abe,None)


    acts_alibris=[[0,10], [0,11],[0,0],[0,7]]
    obs_alibris=[[-1,0,0,0], [10,0,0,0], [11,0,0,0],[0,1,0,0],[7,1,0,0]]

    traj_alibris=types.Trajectory(obs_alibris,acts_alibris,None)

    acts_amazon=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,7]]
    obs_amazon=[[-1,0,0,0],[9,0,0,0], [10,0,0,0],[11,0,0,0], [8,0,0,0], [0,1,0,0], [7,1,0,0]]

    traj_amazon=types.Trajectory(obs_amazon, acts_amazon,None)


    acts_amazon_2=[[0,9],[0,10], [0,11], [0,8], [0,0], [0,13], [0,7]]
    obs_amazon_2=[[-1,0,0,0],[9,0,0,0], [10,0,0,0],[11,0,0,0], [8,0,0,0], [0,1,0,0], [13,1,0,0], [7,1,0,0]]

    traj_amazon_2=types.Trajectory(obs_amazon_2, acts_amazon_2,None)

    acts_barnesandnoble=[[0,15],[0,10],[0,8], [0,0], [0,13],[0,7]]
    obs_barnesandnoble=[[-1,0,1,0],[-1,0,0,0],[10,0,0,0], [8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_barnesandnoble=types.Trajectory(obs_barnesandnoble, acts_barnesandnoble,None)


    acts_newegg=[[0,16],[0,10], [0,11] ,[0,8], [0,0],[0,16], [0,13],[0,16],[0,7]]
    obs_newegg=[[-1,0,1,0],[-1,0,0,0],[10,0,0,0],[11,0,0,0],[8,0,0,0], [0,1,0,1],[0,1,0,0],[13,1,0,1],[13,1,0,0],[7,0,0,0]]

    traj_newegg=types.Trajectory(obs_newegg, acts_newegg,None)


    acts_manomano=[[0,15],[0,9],[0,10],[0,11],[0,11], [0,8], [0,0], [0,13],[0,7]]
    obs_manomano=[[-1,0,1,0],[-1,0,0,0],[9,0,0,0],[10,0,0,0],[11,0,0,0],[11,0,0,0],[8,0,0,0], [0,1,0,0],[13,1,0,0],[7,0,0,0]]

    traj_manomano=types.Trajectory(obs_manomano, acts_manomano,None)
    #acts_walmart=[[1,6],[0,8], [0,0], [0,7]]
    #obs_walmart=[[-1,0],[6,0], [8,0], [0,1], [7,1]]

    #traj_walmart=types.Trajectory(obs_walmart,acts_walmart,None)

    #file=open('expert_walmart_buy_product_search.pkl', 'wb')
    #pickle.dump(np.array([traj_walmart]), file, pickle.HIGHEST_PROTOCOL)
    # file=open('expert_alibris_buy_product_menu.pkl', 'wb')
    # pickle.dump(np.array([traj_alibris]), file, pickle.HIGHEST_PROTOCOL)


    # file=open('expert_amazon_buy_product_menu.pkl', 'wb')
    # pickle.dump(np.array([traj_amazon]), file, pickle.HIGHEST_PROTOCOL)

    # file=open('expert_abebooks_buy_product_menu.pkl', 'wb')
    # pickle.dump(np.array([traj_abe_books]), file, pickle.HIGHEST_PROTOCOL)

    file=open('expert_combined_buy_product_menu_events.pkl', 'wb')
    pickle.dump(np.array([traj_abe_books,traj_alibris,traj_amazon, traj_manomano, traj_newegg]), file, pickle.HIGHEST_PROTOCOL)



main()